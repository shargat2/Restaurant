﻿namespace Restaurant.SupportItems.Models;

public enum OrderType
{
    Starter,
    Main,
    Drink
}
